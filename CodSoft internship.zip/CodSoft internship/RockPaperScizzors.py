import random
def game():
    choices = ["rock", "paper", "scissors"]
    user_points = 0
    comp_points = 0

    while True:
        print("\nWelcome to Rock, Paper, Scissors Game")
        print("1.Rock")
        print("2.Paper")
        print("3.Scissors")
        print("4.Quit")

        choice = input("Enter your choice: ")

        if choice == '4':
            print(f"\nFinal Score ==> Your Score: {user_points}, Computer Score: {comp_points}")
            break

        if choice not in ['1', '2', '3']:
            print("Invalid choice.")
            continue

        user_choice = choices[int(choice) - 1]
        computer_choice = random.choice(choices)

        print(f"\nYou choice: {user_choice}, Computer choice: {computer_choice}.\n")

        if user_choice == computer_choice:
            print(f"Both selected {user_choice}. It's a tie!")
        elif (user_choice == "rock" and computer_choice == "scissors") or \
             (user_choice == "scissors" and computer_choice == "paper") or \
             (user_choice == "paper" and computer_choice == "rock"):
            print("You win!")
            user_points += 1
        else:
            print("You lose!")
            comp_points += 1

        print(f"Final Score ==> Your score: {user_points}, Computer score: {comp_points}\n")

game()