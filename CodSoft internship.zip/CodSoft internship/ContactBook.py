class Person:
    def __init__(self, full_name, phone, email, location):
        self.full_name = full_name
        self.phone = phone
        self.email = email
        self.location = location

class Directory:
    def __init__(self):
        self.contacts = []

    def add_person(self, full_name, phone, email, location):
        new_person = Person(full_name, phone, email, location)
        self.contacts.append(new_person)
        print(f"Person {full_name} added successfully!")

    def view_people(self):
        if not self.contacts:
            print("No people found!")
        else:
            for person in self.contacts:
                print(f"Name: {person.full_name}, Phone: {person.phone}")

    def search_person(self, query):
        found_people = [person for person in self.contacts if query in person.full_name or query in person.phone]
        if not found_people:
            print("No people found!")
        else:
            for person in found_people:
                print(f"Name: {person.full_name}, Phone: {person.phone}")

    def update_person(self, full_name, new_phone=None, new_email=None, new_location=None):
        for person in self.contacts:
            if person.full_name == full_name:
                if new_phone:
                    person.phone = new_phone
                if new_email:
                    person.email = new_email
                if new_location:
                    person.location = new_location
                print(f"Person {full_name} updated successfully!")
                return
        print("Person not found!")

    def delete_person(self, full_name):
        for person in self.contacts:
            if person.full_name == full_name:
                self.contacts.remove(person)
                print(f"Person {full_name} deleted successfully!")
                return
        print("Person not found!")

def main():
    directory = Directory()

    while True:
        print("\nDirectory Management System")
        print("1. Add Person")
        print("2. View People")
        print("3. Search Person")
        print("4. Update Person")
        print("5. Delete Person")
        print("6. Exit")

        choice = input("Enter your choice: ")

        if choice == "1":
            full_name = input("Enter full name: ")
            phone = input("Enter phone number: ")
            email = input("Enter email: ")
            location = input("Enter location: ")
            directory.add_person(full_name, phone, email, location)
        elif choice == "2":
            directory.view_people()
        elif choice == "3":
            query = input("Enter name or phone number to search: ")
            directory.search_person(query)
        elif choice == "4":
            full_name = input("Enter name of person to update: ")
            new_phone = input("Enter new phone number (optional): ")
            new_email = input("Enter new email (optional): ")
            new_location = input("Enter new location (optional): ")
            directory.update_person(full_name, new_phone, new_email, new_location)
        elif choice == "5":
            full_name = input("Enter name of person to delete: ")
            directory.delete_person(full_name)
        elif choice == "6":
            print("Exiting Directory Management System. Goodbye!")
            break
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
